﻿int a = 4;
int b = 5;
int result = a;
for(int i = 1; i < b; i++)
{
    result *=a;
}
Console.WriteLine(result);